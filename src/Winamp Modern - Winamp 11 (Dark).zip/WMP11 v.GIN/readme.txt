Windows Media Player 11 skin 
v. GIN

by Gince80@yahoo.com

Enjoy :)
 