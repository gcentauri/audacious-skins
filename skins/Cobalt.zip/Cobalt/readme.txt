Cobalt is my first attempt at xmms skinning.  I hope you enjoy it.
You'll find the proper GNU GPL licensing information included in this archive.  I encourage you to make modifications and improve on the theme.

Enjoy!
--
Jon Winters winters@obscurasite.com
http://www.obscurasite.com/jon/
