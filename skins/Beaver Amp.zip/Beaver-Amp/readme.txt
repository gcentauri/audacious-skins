Hey!

First of all this skin is brought to you by ekho;yeah me...:)
The skin is based on my own windows theme...

you wanna check my images?

go to:

http://ekho.tx.hu (actually it is forwarded to my cgtalk portfolio becouse of lazyness :D

cheers and save the beavers!

2007/nov.

ekho