=========================================
                            AFFINITY DARK
=========================================
COMPLETED:   2 OCTOBER 2003
RELEASED:    2 OCTOBER 2003

INCLUDES:
 - Skinned Main Window
 - Skinned Equalizer
 - Skinned Playlist Editor
 - Skinned AVS for Winamp 2.91
 - Skinned Winamp Library
 - Skinned Video Player
 - Skinned Mini Browser

ENJOY!

http://diffuse.deviantart.com
