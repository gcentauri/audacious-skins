
 BALAJI Web-Designs: WinAMP Skin

 BWD MediaTower - V2

 This is the official skin of BALAJI Web-Designs.
 
 Version History (Changes):-
 V2.1	Player stands remodelled. (soon)
 V2	Everything is new. Completely new design.
	Balance slider changed to indicator.
	Coloured lights for:-
	Shuffle, Repeat	-	Main
	EQ, Playlist	-	Main
	On, Auto 		-	EQ
	Playlist text font changed.
	Playlist-buttons text is more visible now.
	Main-window is always active.		
 V1	First release.
	BWD Jukebox V2 was my 1st official skin.
	BWD MediaTower is my 2nd official skin. 
	
 Recommended settings:-
 Desktop colour depth - 32 bit.
 Spectrum analyzer - Normal, Peaks & Thick bands
 Oscilliscope - Solid scope
 Best with black or dark wallpapers. 

  MediaTower doesn't support transparency
 because the playlist stands-out. This spoils
 the looks of the whole player.
  If the player and the background don't match,
 try downloading V2.1.

 By Balaji, balaji_webdesign@yahoo.com

 Comments, suggestions , work opportunities,
 anything mail them to the above address. 

 Note: Don't re-distribute online(via websites
 and homepages) without this readme file.
 
 Thanks.

 Copyright 2002 BALAJI Web-Designs (BWD).
 All other copyrights are copyright of their
 respective owners.

