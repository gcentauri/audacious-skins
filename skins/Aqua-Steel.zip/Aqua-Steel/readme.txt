```````````````````````````` AquaSteel 2.0 ````````````````````````````

I revised the entire skin, some people didn't
like version one's buttons, so sourced buttons
from my nexus_blue skin, and transplanted them
with much success...

This is my last personal winamp2 skin, and it
is was also made to commemorate my birthday on
the 4 September... 

I also included the simply_surround pluggin
in the skin archieve, it gives you the best CD/
surround sound quality of any pluggin out there

```````````````````````````` Skin Contents `````````````````````````````

	* Main Control Amp
	* Equilizer
	* Playlist
	* Minibrowser
	* Advanced Visual Studio (AVS)
	* MikroAmp skin 
	* Cursors
	* Albumlist
	* Amarok

	* Simply_surround pluggin

``````````````````````` Additional information `````````````````````````

DSP Plugin Enhancer:

To be able to use it download the plugin from:-
winamp.com
www.geocities.com/i_adryan
www.i-adrian.home.ro

Install it and then extract the file "aquasteel2.bmp" 
to the folder winamp\plugins\enhancer\017*
(017 is the version number of the plugin)

````````````````````````````` Skin Presets `````````````````````````````

For best viewing results use these presets:

1. Set Visualization to Spectrum Analyzer, refresh 
   rate @ 70 fps, Normal Style, Peaks ON and Thick
   bands.

2. Viewed best at 1024X768 pixels resolution and 
   with True color.

`````````````````````````````` Skin Info ```````````````````````````````

This skin was designed using MS Paint,Adobe 
Photoshop 5,MS Notepad and ArcSoft PhotoImpression.

Released :  29 September 2002

Skin no.28

`````````````````````````````` Contact Me ``````````````````````````````

If you have questions or comments or suggestions
for new skins my E-mail address is:-

	Wobbles@websurfer.co.za

If you like this skin and want to download
my other skins goto:-

	www.1001winampskins.com
	www.TSS2000.BIZ
	www.skinz.org
	www.winamp.com

Durban,South Africa

````````````````````````````` Wobbles 2002 `````````````````````````````