> > >   EMKEJX ROYAL BLACK SKIN   < < <

designed by eMKejx
inspiration in Windows XP Royal Black Theme /official/
-

made in: Paintbrush
-
advertisement: www.techmusic.org
-
version history:
22.7.2010 - final release (complete skin)
28.2.2007 - first release (not complete)
