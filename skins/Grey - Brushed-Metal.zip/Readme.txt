SKIN NAME: BrushedMetal XMMS
SKIN VERSION: 1.0
DATE CREATED: 5 October, 1999
SKIN DESIGNERS: JazzMidi & Alf
EMAILS: jazzmidi@mindspring.com
        ried@si.tn.tudelft.nl
SKIN GRAPHICS BY: Tigert (http://tigert.gimp.org tigert@gimp.org)
                                 &
                  The Rasterman (http://www.rasterman.com raster@rasterman.com)
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
SKIN NOTES:
Skin should be used with the Default Enlightenment theme called BrushedMetal.
See http://www.enlightenment.org.

DESIGNER NOTES:
This skin was inspired by the Enlightenment
Theme called BrushedMetal.
We like this theme a LOT.

If you use something like gnomexmms you can make the applet
match the BrushedMEtal theme more by recompiling gnomexmms.
You only have to copy xmms-dock-master-BrushedMetal.xpm over
the standard xmms-dock-master.xpm in the gnomexmms directory.
Recompile and install, and now your gnomexmms looks ok in
BrushedMetal :-)
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
ACKNOWLEDGEMENTS:
To Tigert and The Rasterman for creating a great Etheme
To all the people who created and improved the GIMP :-)


Enjoy using this skin!

JazzMidi
Jazz Alley XG Midis
jazzmidi@mindspring.com

Alf
ried@si.tn.tudelft.nl
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
CHANGE LOG:
V1.0
- First Release
