Fundamental:
>>>>>>>>>>>
Produced and designed by: Ivandekic Darjan skins (IDS)
 
E-mail of producer: darjan87@sksyu.net

Name of skin: Yugoamp

Version: 1.70

Year of create: 2004

Class: classic skin

Size: 38KB

Special thanks:
>>>>>>>>>>>>>>
Skins: Digital Fusion, Pioneer

Programs: Winamp, Jasc Paint Shop7.00, Adobe Photoshop 7.0, Paint

License:
>>>>>>>
This is freeware.
You may make copies and distribute this skin unlimited number of times, send freely to your friends.


Contain:
>>>>>>>
Main skin

Playlist skin

Equalizer skin

Minibrowser skin

Media library skin

Video skin

Cursors

 
End
>>>