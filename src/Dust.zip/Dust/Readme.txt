Dust XMMS Skin v0.1 (pre-beta)
by Laszlo Simon (laszlo.simon@gmail.com)

XMMS compatible skin match with new Dust theme of Ubuntu.

2008 Laszlo Simon. Creative Commons by

Known bugs, missing issues, todo
- Position slider must be shorter at rigth side
- volume slider must be shorter at right side
- eq slider must change look when downed
- close, minimise buttons has to be colored when 
  overed, downed 
- missing shaded skin at each window
- controll icons on playlist window not showed
- correct background of timer in pl window
- use gradient instead of monocolor in EQ display
- use better font/antialiash
- make PL buttons popup window like