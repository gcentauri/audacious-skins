:: Windows Media Player ::
made for all creatures in the universe!

http://koekoeh.deviantart.com
email: koekoehgesang@yahoo.com

This classic Skin made based on Windows Media Player. And all the windows skinned.

-Koekoeh

(C) 2003 ALL GRAPHICS BY Koekoeh
YOU MAY pass this skin as your work
YOU MAY use elements of my skins for your own projects
YOU MAY publish it without my permission
YOU MAY edit this skin for everything you want

04:10 07/08/03