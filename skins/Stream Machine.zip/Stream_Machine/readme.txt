Enjoy the Stream Machine v1 for Winamp 2.9
Made by Frixzi (frixzi@wxs.nl), Aug 2003.
Thanks to Jellby for the Skinner's Atlas v1.5.1


