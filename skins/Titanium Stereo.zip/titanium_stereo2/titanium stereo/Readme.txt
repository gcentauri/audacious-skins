Titanium_stereo_amp V2.01   (13-08-2001)
----------------------------------------------------------------------

This skin is BASED on Pordey's design,  (Pordey is at ppardi@planet.it)
but almost EVERYTHING was changed except for the basic button design.

Author: Fran�ois Paradis (fpara@sympatico.ca)

To get the coolest vizualization for this amp:
(Windows should be set to 16-bit color at least)

1. right-click vizualization area for a menu
2. Set the following:
---------------------------------------------------------------------
Visualization mode - analyzer
Analyzer mode      - normal colors
                   - bars enabled
                   - peaks enabled
Analyzer falloff   - "fastest" 
Peaks falloff      - "faster"
Refresh rate       - "70fps"


enjoy.
































"Demonius est Deus Inversus"
