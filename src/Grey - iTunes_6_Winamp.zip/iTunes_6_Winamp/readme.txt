iTunes 6 Winamp
Based on Apple iTunes 6 for Windows
Skin by TC Falcon
http://www.altmusictv.com/

Version 2.0
November 1, 2005

Version History:
2.0	November 1, 2005 (iTunes 6 Winamp)
1.02	June 9, 2004 (iTunes 4 Winamp)
1.01	December 20, 2003 (iTunes 4 Winamp)
1.0	December 7, 2003 (iTunes 4 Winamp)