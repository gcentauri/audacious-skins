ATERXMMSPlayer v1
by Laszlo Simon (laszlo.simon@gmail.com)

Made for ATER metacity theme. 

2006 Laszlo Simon. General Public License