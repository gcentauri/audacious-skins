Tiger Brushed winamp skin
--------------------------

This winamp skin is based on my port of Tiger. 
StudioTwentyEight - www.studiotwentyeight.com
