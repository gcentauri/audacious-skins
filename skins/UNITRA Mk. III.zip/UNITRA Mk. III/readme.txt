Pierwszy skin jamali.
jamala's first classic skin. Project started 2001 and never ended ;-) .
UNITRA was the polish company producing home appliances like TVs, radios and hi-fis in former times.
UNITRAs were always simple and user friendly, so I wanted to keep up with it.
UNITRA Mk. III skin is now complete with MAIN, PL, EQ, AVS,  MB, MA, VID and GEN modules.
Have fun.
My site (personal, no WA skins): http://jamala.w.interia.pl
