D  I  G  I  T  A  N  I  U  M    v3.0

by Copycat

Redisigned titanium's metallic shine, and playlist LCD. 
Minor bugs fixes, and please report me any.
No real big changes from version 2 in shape, but shades now fit together.
Lightning effects made with PhotoShop 5, and all skin with Paint Shop Pro 6
Digitanium3 -Gold Plated version- in progress


If you want to know how the shape was made, visit 
http://www.ComPorts.Com/AlexV/WSkins.html


thanx for downloading.



Copycat (Patrik)


Thanx to:

Nullsoft Winamp
Alex Vallart (TransTrace)
And all my friends from Paraguay who give their oppinions and suggestions



Made In Paraguay - MM
