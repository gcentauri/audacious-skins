[Astral AMP]

Welcome to Astral AMP, the "cool blue" WinAmp skin.
This skin is actually a heavily modified version of Alpha Amp,
which I thought was pretty cool, besides the ugly orange/green
colour theme. I changed many attributes of the main screen,
including text, colours, LED-style numbers and nicer bevels
around certain objects in the window. All the title fonts were
changed as well.

This is infact my first WinAmp skin, and I'm very happy with the
results. Please note that this skin is to be used only with WinAmp
version 2 or greater. It was designed and tested with version 2.05.


[Contact Information]

If you have any questions or comments, please do one of the following:

email : shadoe@ica.net
ICQ   : 1401611

...or you could just keep your mouth shut.

Brought to you by:


       .||||||.  .|||||||  ||||||||  |||||||.  .||||||.  ||
       ||    ||  ||           ||     ||    ||  ||    ||  ||
       ||||||||   '|||||.     ||     |||||||'  ||||||||  ||
       ||    ||        ||     ||     ||    ||  ||    ||  ||
       ||    ||  |||||||'     ||     ||    ||  ||    ||  ||||||||

          [M        [O        [T        I]        O]        N]

[Astral Motion]