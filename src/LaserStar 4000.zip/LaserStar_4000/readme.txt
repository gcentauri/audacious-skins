LASERstar_4000

LASERstar_4000 is the successor of the original LaserStar_3000 skin. The original skin was created on a computer using wrong contrast settings. The result was that the skin ended up appearing darker on most monitors than was originally intended. This time the problem is fixed. There have also been a couple of bug fixes in the ML, so basicly the skin should work now the way it was supposed to the first time. Have fun with it.

Hespero5