
ULTRAFINA was created by J. Mayled 

for the X Multimedia System (XMMS)

with the GIMP 1.0.1

between June 15-17 1999

Ultrafina.zip contains:

-rw-rw-r--   1 mayled   mayled      88386 Jun 16 15:58 balance.bmp
-rw-rw-r--   1 mayled   mayled      14742 Jun 17 12:05 cbuttons.bmp
-rw-rw-r--   1 mayled   mayled     260874 Jun 17 12:06 eqmain.bmp
-rw-rw-r--   1 mayled   mayled      96102 Jun 17 12:08 main.bmp
-rw-rw-r--   1 mayled   mayled       4278 Jun 17 12:08 monoster.bmp
-rw-rw-r--   1 mayled   mayled       3956 Jun 17 12:08 numbers.bmp
-rw-rw-r--   1 mayled   mayled       1206 Jun 17 12:08 playpaus.bmp
-rw-rw-r--   1 mayled   mayled     156294 Jun 17 12:09 pledit.bmp
-rw-rw-r--   1 mayled   mayled         74 Jun 17 12:09 pledit.txt
-rw-rw-r--   1 mayled   mayled       9294 Jun 17 12:09 posbar.bmp
-rw-rw-r--   1 mayled   mayled       1214 Jun 17 12:20 readme.txt
-rw-rw-r--   1 mayled   mayled      23514 Jun 17 12:09 shufrep.bmp
-rw-rw-r--   1 mayled   mayled       8480 Jun 17 12:09 text.bmp
-rw-rw-r--   1 mayled   mayled      89838 Jun 17 12:09 titlebar.bmp
-rw-rw-r--   1 mayled   mayled        574 Jun 17 12:10 viscolor.txt
-rw-rw-r--   1 mayled   mayled      88386 Jun 17 12:10 volume.bmp





