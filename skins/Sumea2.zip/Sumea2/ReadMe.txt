sumea.amp3 -- now with avs!       11/30/2000
-------------------------------------------------
This skin caught my eye immediately. I loved it!
But I couldn't help but tweak it to my liking.
The most significant changes: the analyzer,
eq/pl, shuffle and vol/pan parts of Main.bmp,
the eq color & spline and the min/max/X buttons.
I also animated volume and balance, tweaked the
playlist txt, background colors, analyzer/scope
shading, some of txt & numbers and more. Now with
avs and other subtle fixes.

I always wanted to calibrate the spectrum analyzer
box, so I generated some tones, played the WAV,
and used the analyzer's lines mode to see exactly
where the freq's fell..
But I soon discovered that the scale is different
for wavs when I played an MP3 and noticed that
the scale was way off. So I converted the WAV to
MP3 at 44k and corrected. Note: the scale is also
off if you play an MP3 other than 44k. It probably
hasn't been "calibrated" due to the varying
streaming sample rates.

Winamp eq bands are labeled to aid in tweaking.

If you want a more natural scale, email me and
I'll send you an MP3 calibration file and
main.bmp with the following values:
.25 .5 1 2 4 8 12 16 kHz.

If enough Streamers out there can't ignore the
scale, I'll edit it out upon request.

Please send feedback if you like this skin.

Enjoy,

chrislowman@yahoo.com

I also modified Sonicated by YUG.

The original maker of sumea.amp is noted below.
Check out the java animations at the site.
I especially like the turtle.
_______________________________________
s u m e a . amp WinAmp skin
by Jarkko Salminen 23/6/1999

Contact: jarkko.salminen@uiah.fi
Visit our website: www.sumea.com
