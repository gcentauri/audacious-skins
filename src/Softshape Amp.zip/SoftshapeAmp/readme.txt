SoftshapeAmp Release II   for Winamp
---------------------------------------
I developed this skin because I wanted clean, easy and usable skin for Winamp. I have been collecting skins for Winamp for more than 2 years, and they currently take 60Mb of my drive space. Most of them are cool! Only recently I realized that I spend too much time looking for button I wanted to click. So I decided to make something maybe not so cool, but easy to use. 

So I put light controls on dark background, added thin border, and almost transparent texture. Thanks http://electrikvoice.deviantart.com/, http://seibetsu.deviantart.com/ for useful improving suggestions. 

So why I did this? Becasue I do not want to impress you too much. I want this skin to stay on your desktop for long, without making you tired of using it. :)

---------------------------------------
A couple of words about me (in case you dont bother going to http://art.softshape.com :)) - 
- 21
- M
- Siberia (********* <- yes a lot of snow!)
- happily married
- in love with wife cat and Paris
- do skins for money
- do sites for money 
- do skins for fun
- love usable things
---------------------------------------

This skin is available in 6 colors. I will post them all at my site.
Thanks for scrolling down, enJoy!

Vlad Gerasimov, SoftshapeArt.