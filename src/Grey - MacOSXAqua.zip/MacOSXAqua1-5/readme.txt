 ________________________________________

  Mac OS X 1.5 (Aqua) by DeeLight
 ________________________________________

  Description:
     After doing my Winamp X skin, I wanted to do
     one that looked even more like the Mac OS X
     Aqua style. So I did Mac OS X, it looked a lot
     closer to the Aqua interface, but still wasn't like
     I wanted it to be. After Apple released Jaguar,
     I started work on this skin, on which I resumed
     work a few months later. Now, it's ready to be
     used, and I hope you like it as much as I do.

     Winamp 2.x has a lot of limitations, so I also
     plan to port this skin to Winamp 3, but keeping
     the classic winamp 2.x style, so stay tuned ;)
 ________________________________________

  Changes since Mac OS X v1.4:
   � Playlist container is now same distance from
     both sides.

  Changes since Mac OS X v1.0:
   � New Buttons (OS X 10.2 [Jaguar] style)
   � New Spectrum Analyzer Colors
   � New Title fonts (Looks Cleaner)
   � New Fonts for Songtitle Display
   � New Time Display Fonts (Sharper & Cleaner)
   � New Volume/Balance Sliders
   � New Containers (where OAIDV, Time, Title,
     Spectrum Analyzer, Kbps, Khz, Mono/Stereo,
     Graphics Equalizer and Playlist Elements are
     located.)
   � New Equalizer Scroll Buttons
   � New Playlist Buttons
   � New Playlist Scroll Button
   � New Winamp Menu Button
   � New Font Alignements and Shadows for Better
     Readability on all the Other Text Elements
   � New Control Buttons in Playlist and Main
     Window in Windowshade Mode
   � New Play/Pause/Stop Images in between
     OAIDV and Song Time. 
   � Winamp and Volume titles are now aligned
     in Windowshade Mode.
   � New Minimize/Windowshade/Close buttons
     with the symbols added.
 ________________________________________

  Contact:
   � www: http://deelight.smartftp.com/
   � email: deelight@smartftp.com
     ( English / French / Polish )

  Notes:
     I think that the songtitle font is better than in
     Mac OS X, but I'm still not completely satisfied.
     If you saw or made a font yourself that you
     think would fit perfectly, please le me know.