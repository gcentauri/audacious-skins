              XXX                          XXX
XXXXXXXXXX   XXXXXXXXXX   XXXXXXXXXX
XXX                 XXX                               XXX
XXXXXXXXXX   XXXXXXXXXX   XXXXXXXXXX
    dcb blue         by dcbel         dec 2011