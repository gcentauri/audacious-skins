TiAmp winamp skin
-----------------

This winamp skin is made to match TiSkin Visual Styles. Original design by Xanthic.

Xanthic Eye - http://www.xanthic.net
Xanthic BB Forums - http://bb.xanthic.net
StudioTwentyEight - http://www.studiotwentyeight.com