i-deck v1.0
=============
All images were skinned using Photoshop 7.0, Service Utility, Skinner Utility.

History:
05-20-2003 Uploaded
- All Main Components skinned,
- All Winshade mode skinned
- Support for AlbumList plug-in (www.cometo/albumlist)
- Support for WA2.9 Media Library and Video
- Supports WinAMP below 2.9, AVS.BMP not Included

05-26-2003
- genx.bmp, change color
- pledit, readable on dark monitors
- library, readable on dark monitors
- vicolor, modified
- albumlist, readable on dark monitors

Author: ely ocbina / e_ocbina
e-mial: e_ocbina@yahoo.com

Trademarks:
Winamp is a registered trademark of nullsoft, Inc.
Adobe Photoshop is a registered trademark of Adobe Systems Inc.
Windows XP, Microsoft, Windows and Windows Logo are trademarks of Microsoft Corp.