This skin is made by Toni "TMT" Tuomikallio for www.finrg.com
Any feedback to tmt@nic.fi

Enjoy!