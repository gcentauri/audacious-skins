Oxygen created for QMMP project by Adrià Arrufat
swiftcythe@gmail.com