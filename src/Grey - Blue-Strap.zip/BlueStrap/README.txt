
. : O R A N G E J U i C E : .
=============================


The complementary XMMS skin designed around the enlightenment theme Orange
Juice.

Released under the terms of the GNU general public license (see file copying
for more information).


for any reason mailto:babyhead.lostmypants.net
