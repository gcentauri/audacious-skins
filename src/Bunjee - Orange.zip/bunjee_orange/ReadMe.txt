--------------------------------------------------------------------------
    -***- "bunjee" Player -***- 

  by Otto Donder (o.donder@chairod.de)

  My fifth XMMS/Audacious/Winamp_5 - Skin.

  2007/12/16 - first public release

  2007 Otto Donder. General Public License

--------------------------------------------------------------------------

http://www.chairod.de
http://http://www.gnome-look.org/usermanager/search.php?username=ottlux

e-mail : o.donder@chairod.de

--------------------------------------------------------------------------

Hope You like it.
