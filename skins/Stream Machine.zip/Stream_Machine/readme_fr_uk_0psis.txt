Internationnal notes :
This winamp skin is based on original material from http://opsis.free.fr
Bitmaps have been designed with Macromedia Flash some Adobe Photoshop.
Due to "special" format of winamp there won't be a new design every week :)
So if you know a real editor for winamp, let me know where I can find it.


French notes:
Cette "skin" winamp est bas� sur le design de ma homepage htt://opsis.free.fr.
Les images ont �t� r�alis�e avec flash 4 et un poil de photoshop.
D� au format vraiment sp�cial de winamp, les possibilit�es sont tr�s
contraignantes, ne comptez pas trop sur une nouvelle "skin" toutes les semaines :)
Si vous connaissez un v�ritable editeur de skins, ecrivez moi.
Le mecanisme est lubrifi� avec des huiles v�g�tales naturelles
et en aucun cas n'utilise de d�riv�s de p�troles

Eric.
email:opsis@free.fr
version 0.92 du 25/05/2000


Install notes : just put 0psis01.wsz in C:\Program Files\Winamp\Skins
or the path where yours skins are installed. 

 